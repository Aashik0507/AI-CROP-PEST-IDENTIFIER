import React, { useState, useEffect } from 'react';
import {
  StyleSheet,
  Text,
  View,
  ScrollView,
  Image,
  TouchableOpacity,
  SafeAreaView,
  Share,
  Platform,
} from 'react-native';
import { useLocalSearchParams, useRouter } from 'expo-router';
import * as Speech from 'expo-speech';
import {
  TRANSLATIONS,
  LanguageCode,
} from '../utils/translations';
import { DetectionRecord, saveDiagnosisToHistory } from '../utils/offlineStorage';
import { getCropEmoji } from '../utils/cropImages';

export default function AnalysisScreen() {
  const router = useRouter();
  const params = useLocalSearchParams();
  const [data, setData] = useState<DetectionRecord | null>(null);
  const [isSpeaking, setIsSpeaking] = useState<boolean>(false);
  const [isSaved, setIsSaved] = useState<boolean>(true);

  useEffect(() => {
    if (params.data) {
      try {
        const parsed = JSON.parse(params.data as string) as DetectionRecord;
        setData(parsed);
      } catch (e) {
        console.error('Error parsing diagnosis payload', e);
      }
    }

    return () => {
      // Stop speech if navigating away
      Speech.stop();
    };
  }, [params.data]);

  if (!data) {
    return (
      <SafeAreaView style={styles.safeArea}>
        <View style={styles.centerContainer}>
          <Text style={styles.loadingText}>Loading analysis results...</Text>
        </View>
      </SafeAreaView>
    );
  }

  const lang = (data.language as LanguageCode) || 'en';
  const t = TRANSLATIONS[lang] || TRANSLATIONS['en'];
  const confidencePercent = Math.round((data.confidence_score || 0.85) * 100);

  const toggleSpeech = async () => {
    if (isSpeaking) {
      Speech.stop();
      setIsSpeaking(false);
      return;
    }

    setIsSpeaking(true);

    const speechText = [
      `${data.crop_type}: ${data.disease_name}.`,
      `${t.treatmentSteps}: ` + data.treatment_steps.join('. '),
      `${t.fertilizerSuggestions}: ` + data.fertilizer_suggestions.join('. '),
      `${t.preventionTips}: ` + data.prevention_tips.join('. '),
    ].join('\n\n');

    // Language code for TTS
    const ttsLocales: Record<string, string> = {
      en: 'en-IN',
      kn: 'kn-IN',
      ta: 'ta-IN',
      te: 'te-IN',
      ml: 'ml-IN',
    };

    Speech.speak(speechText, {
      language: ttsLocales[lang] || 'en-IN',
      rate: 0.9,
      pitch: 1.0,
      onDone: () => setIsSpeaking(false),
      onError: () => setIsSpeaking(false),
      onStopped: () => setIsSpeaking(false),
    });
  };

  const handleShare = async () => {
    try {
      const shareMessage = `🌾 AI Crop Doctor Diagnosis\nCrop: ${data.crop_type}\nDisease: ${data.disease_name}\nConfidence: ${confidencePercent}%\n\nTreatment:\n${data.treatment_steps.map((s, i) => `${i + 1}. ${s}`).join('\n')}`;
      await Share.share({
        message: shareMessage,
      });
    } catch (e) {
      console.error(e);
    }
  };

  return (
    <SafeAreaView style={styles.safeArea}>
      <ScrollView contentContainerStyle={styles.scrollContent} showsVerticalScrollIndicator={false}>
        {/* Top Leaf Image / Thumbnail Card */}
        {data.image_uri ? (
          <View style={styles.imageCard}>
            <Image source={{ uri: data.image_uri }} style={styles.leafImage} resizeMode="cover" />
            <View style={styles.cropBadge}>
              <Text style={styles.cropBadgeText}>
                {getCropEmoji(data.crop_type)} {t.cropNames[data.crop_type] || data.crop_type}
              </Text>
            </View>
          </View>
        ) : (
          <View style={styles.noImageBox}>
            <Text style={styles.cropBadgeText}>
              {getCropEmoji(data.crop_type)} {t.cropNames[data.crop_type] || data.crop_type}
            </Text>
          </View>
        )}

        {/* Diagnosis Header Card */}
        <View style={styles.headerCard}>
          <Text style={styles.diagTitle}>{t.diagnosisResult}</Text>
          <Text style={styles.diseaseName}>{data.disease_name}</Text>

          <View style={styles.scoreRow}>
            <View style={styles.scoreBarBackground}>
              <View style={[styles.scoreBarFill, { width: `${confidencePercent}%` }]} />
            </View>
            <Text style={styles.scoreLabel}>
              {confidencePercent}% {t.confidenceScore}
            </Text>
          </View>

          {/* Action Row: Voice Assistance & Share */}
          <View style={styles.topActionsRow}>
            <TouchableOpacity
              style={[styles.voiceBtn, isSpeaking && styles.voiceBtnActive]}
              onPress={toggleSpeech}
              activeOpacity={0.8}
            >
              <Text style={styles.voiceBtnIcon}>{isSpeaking ? '⏹️' : '🔊'}</Text>
              <Text style={styles.voiceBtnText}>{isSpeaking ? t.stopVoice : t.speakAdvice}</Text>
            </TouchableOpacity>

            <TouchableOpacity style={styles.shareBtn} onPress={handleShare} activeOpacity={0.8}>
              <Text style={styles.shareBtnText}>📤 Share</Text>
            </TouchableOpacity>
          </View>
        </View>

        {/* Treatment Steps Card */}
        <View style={styles.sectionCard}>
          <View style={styles.sectionTitleRow}>
            <Text style={styles.sectionIcon}>💊</Text>
            <Text style={styles.sectionTitle}>{t.treatmentSteps}</Text>
          </View>
          {data.treatment_steps.map((step, idx) => (
            <View key={idx} style={styles.stepItem}>
              <View style={styles.stepBadge}>
                <Text style={styles.stepNumber}>{idx + 1}</Text>
              </View>
              <Text style={styles.stepText}>{step}</Text>
            </View>
          ))}
        </View>

        {/* Fertilizer & Nutrition Card */}
        <View style={styles.sectionCard}>
          <View style={styles.sectionTitleRow}>
            <Text style={styles.sectionIcon}>🧪</Text>
            <Text style={styles.sectionTitle}>{t.fertilizerSuggestions}</Text>
          </View>
          {data.fertilizer_suggestions.map((fert, idx) => (
            <View key={idx} style={styles.bulletItem}>
              <Text style={styles.bulletDot}>•</Text>
              <Text style={styles.bulletText}>{fert}</Text>
            </View>
          ))}
        </View>

        {/* Prevention Tips Card */}
        <View style={styles.sectionCard}>
          <View style={styles.sectionTitleRow}>
            <Text style={styles.sectionIcon}>🛡️</Text>
            <Text style={styles.sectionTitle}>{t.preventionTips}</Text>
          </View>
          {data.prevention_tips.map((tip, idx) => (
            <View key={idx} style={styles.bulletItem}>
              <Text style={styles.bulletDot}>✓</Text>
              <Text style={styles.bulletText}>{tip}</Text>
            </View>
          ))}
        </View>

        {/* Bottom Actions */}
        <View style={styles.bottomNavContainer}>
          <TouchableOpacity
            style={styles.newScanBtn}
            onPress={() => router.replace('/')}
            activeOpacity={0.8}
          >
            <Text style={styles.newScanBtnText}>📸 {t.newScan}</Text>
          </TouchableOpacity>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
    backgroundColor: '#f0fdf4',
  },
  scrollContent: {
    padding: 16,
    paddingBottom: 40,
  },
  centerContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  loadingText: {
    fontSize: 16,
    color: '#059669',
  },
  imageCard: {
    width: '100%',
    height: 220,
    borderRadius: 16,
    overflow: 'hidden',
    position: 'relative',
    marginBottom: 16,
    elevation: 3,
    backgroundColor: '#000',
  },
  leafImage: {
    width: '100%',
    height: '100%',
  },
  noImageBox: {
    backgroundColor: '#10b981',
    borderRadius: 16,
    padding: 16,
    alignItems: 'center',
    marginBottom: 16,
  },
  cropBadge: {
    position: 'absolute',
    bottom: 12,
    left: 12,
    backgroundColor: 'rgba(0, 0, 0, 0.75)',
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 16,
  },
  cropBadgeText: {
    color: '#ffffff',
    fontSize: 14,
    fontWeight: 'bold',
  },
  headerCard: {
    backgroundColor: '#ffffff',
    borderRadius: 16,
    padding: 18,
    marginBottom: 16,
    elevation: 2,
    borderWidth: 1,
    borderColor: '#e5e7eb',
  },
  diagTitle: {
    fontSize: 12,
    textTransform: 'uppercase',
    color: '#6b7280',
    fontWeight: 'bold',
    letterSpacing: 0.8,
  },
  diseaseName: {
    fontSize: 22,
    fontWeight: 'bold',
    color: '#ef4444',
    marginTop: 4,
    marginBottom: 12,
  },
  scoreRow: {
    marginBottom: 16,
  },
  scoreBarBackground: {
    height: 8,
    backgroundColor: '#e5e7eb',
    borderRadius: 4,
    overflow: 'hidden',
    marginBottom: 6,
  },
  scoreBarFill: {
    height: '100%',
    backgroundColor: '#10b981',
    borderRadius: 4,
  },
  scoreLabel: {
    fontSize: 12,
    color: '#374151',
    fontWeight: '600',
  },
  topActionsRow: {
    flexDirection: 'row',
    gap: 12,
    marginTop: 4,
  },
  voiceBtn: {
    flex: 2,
    backgroundColor: '#10b981',
    minHeight: 48,
    borderRadius: 12,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: 12,
  },
  voiceBtnActive: {
    backgroundColor: '#ef4444',
  },
  voiceBtnIcon: {
    fontSize: 18,
    marginRight: 8,
  },
  voiceBtnText: {
    color: '#ffffff',
    fontWeight: 'bold',
    fontSize: 14,
  },
  shareBtn: {
    flex: 1,
    backgroundColor: '#e5e7eb',
    minHeight: 48,
    borderRadius: 12,
    alignItems: 'center',
    justifyContent: 'center',
  },
  shareBtnText: {
    color: '#374151',
    fontWeight: 'bold',
    fontSize: 14,
  },
  sectionCard: {
    backgroundColor: '#ffffff',
    borderRadius: 16,
    padding: 16,
    marginBottom: 16,
    elevation: 2,
    borderWidth: 1,
    borderColor: '#e5e7eb',
  },
  sectionTitleRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 12,
  },
  sectionIcon: {
    fontSize: 20,
    marginRight: 8,
  },
  sectionTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#111827',
  },
  stepItem: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    marginBottom: 10,
  },
  stepBadge: {
    backgroundColor: '#d1fae5',
    width: 26,
    height: 26,
    borderRadius: 13,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 10,
    marginTop: 2,
  },
  stepNumber: {
    color: '#059669',
    fontWeight: 'bold',
    fontSize: 13,
  },
  stepText: {
    flex: 1,
    fontSize: 14,
    color: '#374151',
    lineHeight: 20,
  },
  bulletItem: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    marginBottom: 8,
  },
  bulletDot: {
    color: '#10b981',
    fontWeight: 'bold',
    fontSize: 16,
    marginRight: 8,
    lineHeight: 20,
  },
  bulletText: {
    flex: 1,
    fontSize: 14,
    color: '#374151',
    lineHeight: 20,
  },
  bottomNavContainer: {
    marginTop: 10,
  },
  newScanBtn: {
    backgroundColor: '#059669',
    minHeight: 52,
    borderRadius: 14,
    alignItems: 'center',
    justifyContent: 'center',
    elevation: 3,
  },
  newScanBtnText: {
    color: '#ffffff',
    fontSize: 16,
    fontWeight: 'bold',
  },
});
