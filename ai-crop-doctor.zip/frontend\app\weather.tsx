import React, { useState, useEffect } from 'react';
import {
  StyleSheet,
  Text,
  View,
  ScrollView,
  TouchableOpacity,
  ActivityIndicator,
  SafeAreaView,
} from 'react-native';
import * as Location from 'expo-location';
import * as Speech from 'expo-speech';
import {
  TRANSLATIONS,
  LanguageCode,
} from '../utils/translations';
import { getSelectedLanguage } from '../utils/offlineStorage';
import { getCropEmoji } from '../utils/cropImages';

const API_BASE_URL = process.env.EXPO_PUBLIC_API_URL || 'http://127.0.0.1:8000';

const POPULAR_CROPS = ["Rice", "Tomato", "Cotton", "Maize", "Sugarcane", "Wheat", "Banana", "Turmeric"];

interface WeatherData {
  location: string;
  temperature: number;
  humidity: number;
  wind_speed_kmh: number;
  rain_probability_pct: number;
  weather_condition: string;
  crop_type: string;
  crop_advice: string[];
}

export default function WeatherScreen() {
  const [lang, setLang] = useState<LanguageCode>('en');
  const [selectedCrop, setSelectedCrop] = useState<string>('Rice');
  const [weatherData, setWeatherData] = useState<WeatherData | null>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [isSpeaking, setIsSpeaking] = useState<boolean>(false);
  const [coords, setCoords] = useState<{ latitude: number; longitude: number }>({
    latitude: 12.9716,
    longitude: 77.5946,
  });

  const t = TRANSLATIONS[lang] || TRANSLATIONS['en'];

  useEffect(() => {
    (async () => {
      const savedLang = await getSelectedLanguage();
      setLang(savedLang);

      try {
        const { status } = await Location.requestForegroundPermissionsAsync();
        if (status === 'granted') {
          const loc = await Location.getCurrentPositionAsync({});
          const newCoords = {
            latitude: loc.coords.latitude,
            longitude: loc.coords.longitude,
          };
          setCoords(newCoords);
          await fetchWeather(newCoords.latitude, newCoords.longitude, selectedCrop, savedLang);
          return;
        }
      } catch (err) {
        console.warn('Location fetch issue, using default farm coordinates:', err);
      }

      await fetchWeather(coords.latitude, coords.longitude, selectedCrop, savedLang);
    })();

    return () => {
      Speech.stop();
    };
  }, []);

  const fetchWeather = async (
    lat: number,
    lon: number,
    crop: string,
    currentLang: LanguageCode
  ) => {
    setLoading(true);
    try {
      const res = await fetch(
        `${API_BASE_URL}/api/weather-advisory?latitude=${lat}&longitude=${lon}&crop_type=${crop}&language=${currentLang}`
      );
      if (res.ok) {
        const json = await res.json();
        setWeatherData(json);
      } else {
        throw new Error('API response not ok');
      }
    } catch {
      // Local fallback if backend or network is down
      setWeatherData({
        location: `Farm Region (${lat.toFixed(2)}°N, ${lon.toFixed(2)}°E)`,
        temperature: 29.0,
        humidity: 68,
        wind_speed_kmh: 14.0,
        rain_probability_pct: 15,
        weather_condition: "Partly Cloudy",
        crop_type: crop,
        crop_advice: [
          currentLang === 'kn'
            ? "ಮಧ್ಯಾಹ್ನದ ಬಿಸಿಲಿನ ನಂತರ ಹನಿ ನೀರಾವರಿ ನೀಡುವುದು ಸೂಕ್ತ."
            : currentLang === 'ta'
            ? "மாலை வேளையில் பாசனம் செய்வது உகந்தது."
            : currentLang === 'te'
            ? "సాయంత్రం వేళల్లో నీటిపారుదల చేయడం మంచిది."
            : currentLang === 'ml'
            ? "വൈകുന്നേരം നനയ്ക്കുന്നത് ചെടികൾക്ക് ഉത്തമമാണ്."
            : "Moderate humidity. Ideal window for fertigation and weed monitoring.",
          currentLang === 'kn'
            ? "ಮುಂದಿನ 24 ಗಂಟೆಗಳಲ್ಲಿ ಭಾರಿ ಮಳೆಯ ಲಕ್ಷಣಗಳಿಲ್ಲ."
            : currentLang === 'ta'
            ? "அடுத்த 24 மணி நேரத்திற்கு பலத்த மழைக்கான வாய்ப்பில்லை."
            : currentLang === 'te'
            ? "రాబోయే 24 గంటల్లో భారీ వర్ష సూచన లేదు."
            : currentLang === 'ml'
            ? "അടുത്ത 24 മണിക്കൂറിൽ ശക്തമായ മഴയ്ക്ക് സാധ്യതയില്ല."
            : "Low rain probability (15%). Safe conditions for nutrient spraying.",
        ],
      });
    } finally {
      setLoading(false);
    }
  };

  const handleCropChange = (crop: string) => {
    setSelectedCrop(crop);
    fetchWeather(coords.latitude, coords.longitude, crop, lang);
  };

  const toggleSpeech = () => {
    if (isSpeaking) {
      Speech.stop();
      setIsSpeaking(false);
      return;
    }

    if (!weatherData) return;

    setIsSpeaking(true);
    const speechText = [
      `${t.weatherTitle}. ${weatherData.weather_condition}, ${weatherData.temperature}°C.`,
      `${t.cropAdvice} ${weatherData.crop_type}:`,
      weatherData.crop_advice.join('. '),
    ].join('\n\n');

    const ttsLocales: Record<string, string> = {
      en: 'en-IN',
      kn: 'kn-IN',
      ta: 'ta-IN',
      te: 'te-IN',
      ml: 'ml-IN',
    };

    Speech.speak(speechText, {
      language: ttsLocales[lang] || 'en-IN',
      rate: 0.9,
      pitch: 1.0,
      onDone: () => setIsSpeaking(false),
      onError: () => setIsSpeaking(false),
    });
  };

  return (
    <SafeAreaView style={styles.safeArea}>
      <ScrollView contentContainerStyle={styles.scrollContent} showsVerticalScrollIndicator={false}>
        {/* Weather Card Header */}
        <View style={styles.mainWeatherCard}>
          <View style={styles.weatherCardHeader}>
            <View>
              <Text style={styles.locationTitle}>📍 {weatherData?.location || 'Your Farm Location'}</Text>
              <Text style={styles.conditionText}>{weatherData?.weather_condition || 'Partly Cloudy'}</Text>
            </View>
            <Text style={styles.weatherConditionEmoji}>⛅</Text>
          </View>

          <View style={styles.tempRow}>
            <Text style={styles.tempValue}>{weatherData ? `${weatherData.temperature}°` : '--'}</Text>
            <Text style={styles.tempUnit}>C</Text>
          </View>

          {/* Grid of Weather Metrics */}
          <View style={styles.metricsGrid}>
            <View style={styles.metricBox}>
              <Text style={styles.metricIcon}>💧</Text>
              <Text style={styles.metricLabel}>{t.humidity}</Text>
              <Text style={styles.metricValue}>{weatherData?.humidity ?? '--'}%</Text>
            </View>

            <View style={styles.metricBox}>
              <Text style={styles.metricIcon}>💨</Text>
              <Text style={styles.metricLabel}>{t.windSpeed}</Text>
              <Text style={styles.metricValue}>{weatherData?.wind_speed_kmh ?? '--'} km/h</Text>
            </View>

            <View style={styles.metricBox}>
              <Text style={styles.metricIcon}>🌧️</Text>
              <Text style={styles.metricLabel}>{t.rainChance}</Text>
              <Text style={styles.metricValue}>{weatherData?.rain_probability_pct ?? '--'}%</Text>
            </View>
          </View>
        </View>

        {/* Crop Selection Bar for Weather Advisory */}
        <View style={styles.cropSelectorSection}>
          <Text style={styles.cropSelectorTitle}>🌾 Choose Crop for Specific Advisory:</Text>
          <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.cropPillScroll}>
            {POPULAR_CROPS.map((crop) => {
              const isSelected = selectedCrop === crop;
              return (
                <TouchableOpacity
                  key={crop}
                  style={[styles.cropPill, isSelected && styles.cropPillSelected]}
                  onPress={() => handleCropChange(crop)}
                >
                  <Text style={styles.cropPillEmoji}>{getCropEmoji(crop)}</Text>
                  <Text style={[styles.cropPillText, isSelected && styles.cropPillTextSelected]}>
                    {t.cropNames[crop] || crop}
                  </Text>
                </TouchableOpacity>
              );
            })}
          </ScrollView>
        </View>

        {/* Agro-Climatic Advisory Section */}
        <View style={styles.advisoryCard}>
          <View style={styles.advisoryHeaderRow}>
            <View style={styles.advisoryTitleGroup}>
              <Text style={styles.advisoryIcon}>💡</Text>
              <Text style={styles.advisoryTitle}>
                {t.cropAdvice} ({t.cropNames[selectedCrop] || selectedCrop})
              </Text>
            </View>

            {/* Voice Readout Button */}
            <TouchableOpacity
              style={[styles.voiceBtn, isSpeaking && styles.voiceBtnActive]}
              onPress={toggleSpeech}
            >
              <Text style={styles.voiceBtnText}>{isSpeaking ? '⏹️ Stop' : '🔊 Listen'}</Text>
            </TouchableOpacity>
          </View>

          {loading ? (
            <ActivityIndicator color="#10b981" style={{ marginVertical: 20 }} />
          ) : (
            weatherData?.crop_advice.map((adv, idx) => (
              <View key={idx} style={styles.adviceItem}>
                <Text style={styles.adviceCheck}>✓</Text>
                <Text style={styles.adviceText}>{adv}</Text>
              </View>
            ))
          )}
        </View>

        {/* Refresh Action */}
        <TouchableOpacity
          style={styles.refreshBtn}
          onPress={() => fetchWeather(coords.latitude, coords.longitude, selectedCrop, lang)}
          activeOpacity={0.8}
        >
          <Text style={styles.refreshBtnText}>🔄 {t.refresh} Weather</Text>
        </TouchableOpacity>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
    backgroundColor: '#f0fdf4',
  },
  scrollContent: {
    padding: 16,
    paddingBottom: 40,
  },
  mainWeatherCard: {
    backgroundColor: '#10b981',
    borderRadius: 20,
    padding: 20,
    marginBottom: 20,
    elevation: 4,
    shadowColor: '#059669',
    shadowOpacity: 0.3,
    shadowRadius: 10,
  },
  weatherCardHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  locationTitle: {
    fontSize: 14,
    fontWeight: 'bold',
    color: '#ffffff',
  },
  conditionText: {
    fontSize: 16,
    color: '#d1fae5',
    fontWeight: '600',
    marginTop: 2,
  },
  weatherConditionEmoji: {
    fontSize: 40,
  },
  tempRow: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    marginVertical: 14,
  },
  tempValue: {
    fontSize: 48,
    fontWeight: 'bold',
    color: '#ffffff',
  },
  tempUnit: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#d1fae5',
    marginTop: 6,
    marginLeft: 2,
  },
  metricsGrid: {
    flexDirection: 'row',
    backgroundColor: 'rgba(255, 255, 255, 0.2)',
    borderRadius: 14,
    padding: 12,
    justifyContent: 'space-between',
  },
  metricBox: {
    flex: 1,
    alignItems: 'center',
  },
  metricIcon: {
    fontSize: 20,
    marginBottom: 4,
  },
  metricLabel: {
    fontSize: 11,
    color: '#ffffff',
    fontWeight: '600',
  },
  metricValue: {
    fontSize: 14,
    fontWeight: 'bold',
    color: '#ffffff',
    marginTop: 2,
  },
  cropSelectorSection: {
    marginBottom: 20,
  },
  cropSelectorTitle: {
    fontSize: 14,
    fontWeight: 'bold',
    color: '#1f2937',
    marginBottom: 10,
  },
  cropPillScroll: {
    flexDirection: 'row',
  },
  cropPill: {
    backgroundColor: '#ffffff',
    borderRadius: 20,
    paddingHorizontal: 14,
    paddingVertical: 8,
    marginRight: 10,
    flexDirection: 'row',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: '#e5e7eb',
  },
  cropPillSelected: {
    backgroundColor: '#d1fae5',
    borderColor: '#10b981',
  },
  cropPillEmoji: {
    fontSize: 16,
    marginRight: 6,
  },
  cropPillText: {
    fontSize: 13,
    color: '#374151',
    fontWeight: '600',
  },
  cropPillTextSelected: {
    color: '#059669',
    fontWeight: 'bold',
  },
  advisoryCard: {
    backgroundColor: '#ffffff',
    borderRadius: 16,
    padding: 18,
    marginBottom: 20,
    elevation: 2,
    borderWidth: 1,
    borderColor: '#e5e7eb',
  },
  advisoryHeaderRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 14,
  },
  advisoryTitleGroup: {
    flexDirection: 'row',
    alignItems: 'center',
    flex: 1,
    marginRight: 8,
  },
  advisoryIcon: {
    fontSize: 22,
    marginRight: 8,
  },
  advisoryTitle: {
    fontSize: 15,
    fontWeight: 'bold',
    color: '#111827',
    flex: 1,
  },
  voiceBtn: {
    backgroundColor: '#10b981',
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 14,
  },
  voiceBtnActive: {
    backgroundColor: '#ef4444',
  },
  voiceBtnText: {
    color: '#ffffff',
    fontSize: 12,
    fontWeight: 'bold',
  },
  adviceItem: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    marginBottom: 10,
    backgroundColor: '#f9fafb',
    padding: 10,
    borderRadius: 10,
  },
  adviceCheck: {
    color: '#10b981',
    fontWeight: 'bold',
    fontSize: 16,
    marginRight: 8,
  },
  adviceText: {
    flex: 1,
    fontSize: 14,
    color: '#374151',
    lineHeight: 20,
  },
  refreshBtn: {
    backgroundColor: '#ffffff',
    minHeight: 48,
    borderRadius: 14,
    borderWidth: 1,
    borderColor: '#10b981',
    justifyContent: 'center',
    alignItems: 'center',
  },
  refreshBtnText: {
    color: '#059669',
    fontSize: 15,
    fontWeight: 'bold',
  },
});
