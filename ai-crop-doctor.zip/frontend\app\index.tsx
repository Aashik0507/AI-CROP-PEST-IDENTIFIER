import React, { useState, useEffect } from 'react';
import {
  StyleSheet,
  Text,
  View,
  TouchableOpacity,
  ScrollView,
  Image,
  ActivityIndicator,
  Modal,
  Alert,
  SafeAreaView,
  Platform,
} from 'react-native';
import { useRouter } from 'expo-router';
import * as ImagePicker from 'expo-image-picker';
import {
  TRANSLATIONS,
  SUPPORTED_LANGUAGES,
  LanguageCode,
} from '../utils/translations';
import {
  CROP_CATEGORIES,
  getCropImageSync,
  getCropEmoji,
} from '../utils/cropImages';
import {
  getSelectedLanguage,
  saveSelectedLanguage,
  saveDiagnosisToHistory,
  getOfflineDiagnosis,
} from '../utils/offlineStorage';

const ALL_CROPS = [
  "Rice", "Maize", "Wheat",
  "Cotton", "Sugarcane",
  "Turmeric", "Pepper",
  "Coconut", "Arecanut",
  "Tomato", "Potato",
  "Banana", "Mango", "Apple", "Orange", "Grapes", "Strawberry", "Papaya", "Guava", "Pomegranate"
];

const API_BASE_URL = process.env.EXPO_PUBLIC_API_URL || 'http://127.0.0.1:8000';

export default function HomeScreen() {
  const router = useRouter();
  const [lang, setLang] = useState<LanguageCode>('en');
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [selectedCrop, setSelectedCrop] = useState<string>('Tomato');
  const [selectedImage, setSelectedImage] = useState<string | null>(null);
  const [imagePayload, setImagePayload] = useState<string | null>(null);
  const [loading, setLoading] = useState<boolean>(false);
  const [langModalVisible, setLangModalVisible] = useState<boolean>(false);
  const [isOnline, setIsOnline] = useState<boolean>(true);

  const t = TRANSLATIONS[lang];

  useEffect(() => {
    (async () => {
      const savedLang = await getSelectedLanguage();
      setLang(savedLang);
      checkBackendHealth();
    })();
  }, []);

  const checkBackendHealth = async () => {
    try {
      const res = await fetch(`${API_BASE_URL}/api/health`, { method: 'GET' });
      setIsOnline(res.ok);
    } catch {
      setIsOnline(false);
    }
  };

  const handleLanguageSelect = async (code: LanguageCode) => {
    setLang(code);
    await saveSelectedLanguage(code);
    setLangModalVisible(false);
  };

  const pickImageFromGallery = async () => {
    try {
      const { status } = await ImagePicker.requestMediaLibraryPermissionsAsync();
      if (status !== 'granted') {
        Alert.alert('Permission Denied', 'Camera roll permission is required to select photos.');
        return;
      }
      const result = await ImagePicker.launchImageLibraryAsync({
        mediaTypes: ImagePicker.MediaTypeOptions.Images,
        allowsEditing: true,
        aspect: [4, 3],
        quality: 0.7,
        base64: true,
      });

      if (!result.canceled && result.assets[0].uri) {
        setSelectedImage(result.assets[0].uri);
        setImagePayload(result.assets[0].base64 || null);
      }
    } catch (e) {
      console.error(e);
    }
  };

  const takePhotoWithCamera = async () => {
    try {
      const { status } = await ImagePicker.requestCameraPermissionsAsync();
      if (status !== 'granted') {
        Alert.alert('Permission Denied', 'Camera permission is required to capture leaf photos.');
        return;
      }
      const result = await ImagePicker.launchCameraAsync({
        allowsEditing: true,
        aspect: [4, 3],
        quality: 0.7,
        base64: true,
      });

      if (!result.canceled && result.assets[0].uri) {
        setSelectedImage(result.assets[0].uri);
        setImagePayload(result.assets[0].base64 || null);
      }
    } catch (e) {
      console.error(e);
    }
  };

  const handleDiagnose = async () => {
    if (!selectedImage && !imagePayload) {
      Alert.alert(
        t.selectCrop,
        t.takePhoto + ' / ' + t.pickGallery
      );
      return;
    }

    setLoading(true);

    try {
      let diagnosisData;

      // Try calling the backend API
      try {
        const response = await fetch(`${API_BASE_URL}/api/detect-disease`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            image: imagePayload || 'mock_base64_sample',
            crop_type: selectedCrop,
            language: lang,
          }),
        });

        if (response.ok) {
          diagnosisData = await response.json();
        }
      } catch (networkErr) {
        console.warn('Backend unavailable, switching to offline fallback mode:', networkErr);
      }

      // If backend failed or was unreachable, use offline knowledge engine
      if (!diagnosisData) {
        diagnosisData = getOfflineDiagnosis(selectedCrop, lang);
      }

      // Attach image preview uri
      diagnosisData.image_uri = selectedImage;

      // Save to local history
      await saveDiagnosisToHistory(diagnosisData);

      // Navigate to analysis screen
      router.push({
        pathname: '/analysis',
        params: {
          data: JSON.stringify(diagnosisData),
        },
      });
    } catch (err) {
      Alert.alert('Error', 'Unable to complete diagnosis. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const filteredCrops = selectedCategory === 'All'
    ? ALL_CROPS
    : CROP_CATEGORIES[selectedCategory] || ALL_CROPS;

  return (
    <SafeAreaView style={styles.safeArea}>
      {/* Top App Header */}
      <View style={styles.topHeader}>
        <View style={styles.titleContainer}>
          <Text style={styles.appTitle}>🌾 {t.appTitle}</Text>
          <Text style={styles.appTagline}>{t.appTagline}</Text>
        </View>

        {/* Language Selection Pill */}
        <TouchableOpacity
          style={styles.langButton}
          onPress={() => setLangModalVisible(true)}
          activeOpacity={0.8}
        >
          <Text style={styles.langButtonText}>
            🌐 {SUPPORTED_LANGUAGES.find((l) => l.code === lang)?.nativeName || 'EN'}
          </Text>
        </TouchableOpacity>
      </View>

      <ScrollView contentContainerStyle={styles.scrollContent} showsVerticalScrollIndicator={false}>
        {/* Status / Quick Action Banner */}
        <View style={styles.statusRow}>
          <View style={[styles.statusBadge, isOnline ? styles.onlineBadge : styles.offlineBadge]}>
            <View style={[styles.statusDot, isOnline ? styles.onlineDot : styles.offlineDot]} />
            <Text style={styles.statusText}>{isOnline ? t.onlineNotice : t.offlineNotice}</Text>
          </View>
        </View>

        {/* Quick Nav: Weather & History */}
        <View style={styles.quickNavRow}>
          <TouchableOpacity
            style={styles.quickNavCard}
            onPress={() => router.push('/weather')}
            activeOpacity={0.8}
          >
            <Text style={styles.quickNavIcon}>🌤️</Text>
            <View>
              <Text style={styles.quickNavTitle}>{t.weatherTitle}</Text>
              <Text style={styles.quickNavSub}>Live advisory</Text>
            </View>
          </TouchableOpacity>

          <TouchableOpacity
            style={styles.quickNavCard}
            onPress={() => router.push('/history')}
            activeOpacity={0.8}
          >
            <Text style={styles.quickNavIcon}>📋</Text>
            <View>
              <Text style={styles.quickNavTitle}>{t.historyTitle}</Text>
              <Text style={styles.quickNavSub}>Past scans</Text>
            </View>
          </TouchableOpacity>
        </View>

        {/* Crop Selector Section */}
        <View style={styles.sectionHeader}>
          <Text style={styles.sectionTitle}>{t.selectCrop}</Text>
          <Text style={styles.cropCountBadge}>{filteredCrops.length} crops</Text>
        </View>

        {/* Category Pills */}
        <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.categoryScroll}>
          {['All', 'Cereals', 'Cash Crops', 'Spices', 'Plantation', 'Vegetables', 'Fruits'].map((cat) => {
            const isSelected = selectedCategory === cat;
            return (
              <TouchableOpacity
                key={cat}
                style={[styles.categoryPill, isSelected && styles.categoryPillActive]}
                onPress={() => setSelectedCategory(cat)}
              >
                <Text style={[styles.categoryPillText, isSelected && styles.categoryPillTextActive]}>
                  {cat === 'All'
                    ? t.allCrops
                    : cat === 'Cereals'
                    ? t.cereals
                    : cat === 'Cash Crops'
                    ? t.cashCrops
                    : cat === 'Spices'
                    ? t.spices
                    : cat === 'Plantation'
                    ? t.plantation
                    : cat === 'Vegetables'
                    ? t.vegetables
                    : t.fruits}
                </Text>
              </TouchableOpacity>
            );
          })}
        </ScrollView>

        {/* Crop Grid (Horizontal Carousel / Grid) */}
        <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.cropListScroll}>
          {filteredCrops.map((crop) => {
            const isSelected = selectedCrop === crop;
            const localName = t.cropNames[crop] || crop;
            return (
              <TouchableOpacity
                key={crop}
                style={[styles.cropCard, isSelected && styles.cropCardSelected]}
                onPress={() => setSelectedCrop(crop)}
                activeOpacity={0.8}
              >
                <Image
                  source={{ uri: getCropImageSync(crop) }}
                  style={styles.cropThumbnail}
                  resizeMode="cover"
                />
                <View style={styles.cropCardInfo}>
                  <Text style={styles.cropEmoji}>{getCropEmoji(crop)}</Text>
                  <Text style={[styles.cropName, isSelected && styles.cropNameSelected]} numberOfLines={1}>
                    {localName}
                  </Text>
                  <Text style={styles.cropSubName} numberOfLines={1}>
                    {crop}
                  </Text>
                </View>
                {isSelected && <View style={styles.checkmarkBadge}><Text style={styles.checkText}>✓</Text></View>}
              </TouchableOpacity>
            );
          })}
        </ScrollView>

        {/* Photo Capture / Upload Card */}
        <View style={styles.uploadCard}>
          <Text style={styles.uploadCardTitle}>📸 {t.analyzingSubtitle}</Text>

          {selectedImage ? (
            <View style={styles.previewContainer}>
              <Image source={{ uri: selectedImage }} style={styles.previewImage} />
              <TouchableOpacity
                style={styles.removeImageBtn}
                onPress={() => {
                  setSelectedImage(null);
                  setImagePayload(null);
                }}
              >
                <Text style={styles.removeImageText}>✕ Remove</Text>
              </TouchableOpacity>
            </View>
          ) : (
            <View style={styles.emptyPreviewBox}>
              <Text style={styles.emptyPreviewEmoji}>🍃</Text>
              <Text style={styles.emptyPreviewText}>Capture or upload leaf photo</Text>
              <Text style={styles.selectedCropNotice}>Selected Crop: {t.cropNames[selectedCrop] || selectedCrop}</Text>
            </View>
          )}

          <View style={styles.photoActionsRow}>
            <TouchableOpacity
              style={[styles.actionButton, styles.cameraButton]}
              onPress={takePhotoWithCamera}
              activeOpacity={0.8}
            >
              <Text style={styles.actionBtnIcon}>📷</Text>
              <Text style={styles.actionBtnText}>{t.takePhoto}</Text>
            </TouchableOpacity>

            <TouchableOpacity
              style={[styles.actionButton, styles.galleryButton]}
              onPress={pickImageFromGallery}
              activeOpacity={0.8}
            >
              <Text style={styles.actionBtnIcon}>🖼️</Text>
              <Text style={styles.actionBtnText}>{t.pickGallery}</Text>
            </TouchableOpacity>
          </View>
        </View>

        {/* Big Farmer-Friendly Diagnose Action Button */}
        <TouchableOpacity
          style={[styles.diagnoseBtn, loading && styles.diagnoseBtnDisabled]}
          onPress={handleDiagnose}
          disabled={loading}
          activeOpacity={0.85}
        >
          {loading ? (
            <View style={styles.loadingRow}>
              <ActivityIndicator color="#ffffff" size="small" />
              <Text style={styles.diagnoseBtnText}> {t.analyzingLeaf}</Text>
            </View>
          ) : (
            <Text style={styles.diagnoseBtnText}>🔍 {t.diagnoseButton}</Text>
          )}
        </TouchableOpacity>
      </ScrollView>

      {/* Language Selection Modal */}
      <Modal
        visible={langModalVisible}
        transparent={true}
        animationType="fade"
        onRequestClose={() => setLangModalVisible(false)}
      >
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <Text style={styles.modalHeaderTitle}>🌐 {t.selectLanguage}</Text>
            {SUPPORTED_LANGUAGES.map((item) => (
              <TouchableOpacity
                key={item.code}
                style={[styles.langModalItem, lang === item.code && styles.langModalItemActive]}
                onPress={() => handleLanguageSelect(item.code)}
              >
                <View>
                  <Text style={[styles.langItemNative, lang === item.code && styles.langItemTextActive]}>
                    {item.nativeName}
                  </Text>
                  <Text style={styles.langItemEnglish}>{item.name}</Text>
                </View>
                {lang === item.code && <Text style={styles.langSelectedCheck}>✓</Text>}
              </TouchableOpacity>
            ))}
            <TouchableOpacity
              style={styles.modalCloseBtn}
              onPress={() => setLangModalVisible(false)}
            >
              <Text style={styles.modalCloseBtnText}>Close</Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
    backgroundColor: '#059669',
  },
  topHeader: {
    backgroundColor: '#10b981',
    paddingHorizontal: 16,
    paddingTop: Platform.OS === 'android' ? 36 : 12,
    paddingBottom: 16,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    borderBottomLeftRadius: 16,
    borderBottomRightRadius: 16,
    elevation: 4,
    shadowColor: '#000',
    shadowOpacity: 0.1,
    shadowRadius: 6,
  },
  titleContainer: {
    flex: 1,
  },
  appTitle: {
    fontSize: 22,
    fontWeight: 'bold',
    color: '#ffffff',
  },
  appTagline: {
    fontSize: 12,
    color: '#d1fae5',
    marginTop: 2,
  },
  langButton: {
    backgroundColor: 'rgba(255, 255, 255, 0.25)',
    paddingHorizontal: 14,
    paddingVertical: 8,
    borderRadius: 20,
    borderWidth: 1,
    borderColor: 'rgba(255, 255, 255, 0.4)',
  },
  langButtonText: {
    color: '#ffffff',
    fontWeight: 'bold',
    fontSize: 14,
  },
  scrollContent: {
    backgroundColor: '#f0fdf4',
    padding: 16,
    paddingBottom: 40,
  },
  statusRow: {
    marginBottom: 12,
  },
  statusBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 12,
  },
  onlineBadge: {
    backgroundColor: '#dcfce7',
  },
  offlineBadge: {
    backgroundColor: '#fee2e2',
  },
  statusDot: {
    width: 8,
    height: 8,
    borderRadius: 4,
    marginRight: 8,
  },
  onlineDot: {
    backgroundColor: '#10b981',
  },
  offlineDot: {
    backgroundColor: '#ef4444',
  },
  statusText: {
    fontSize: 12,
    fontWeight: '600',
    color: '#1f2937',
  },
  quickNavRow: {
    flexDirection: 'row',
    gap: 12,
    marginBottom: 20,
  },
  quickNavCard: {
    flex: 1,
    backgroundColor: '#ffffff',
    borderRadius: 14,
    padding: 12,
    flexDirection: 'row',
    alignItems: 'center',
    elevation: 2,
    shadowColor: '#000',
    shadowOpacity: 0.05,
    shadowRadius: 4,
    borderWidth: 1,
    borderColor: '#e5e7eb',
  },
  quickNavIcon: {
    fontSize: 26,
    marginRight: 10,
  },
  quickNavTitle: {
    fontSize: 14,
    fontWeight: 'bold',
    color: '#111827',
  },
  quickNavSub: {
    fontSize: 11,
    color: '#6b7280',
  },
  sectionHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 10,
  },
  sectionTitle: {
    fontSize: 17,
    fontWeight: 'bold',
    color: '#111827',
  },
  cropCountBadge: {
    fontSize: 12,
    color: '#059669',
    backgroundColor: '#d1fae5',
    paddingHorizontal: 8,
    paddingVertical: 3,
    borderRadius: 8,
    fontWeight: '600',
  },
  categoryScroll: {
    marginBottom: 14,
  },
  categoryPill: {
    backgroundColor: '#e5e7eb',
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 20,
    marginRight: 8,
  },
  categoryPillActive: {
    backgroundColor: '#10b981',
  },
  categoryPillText: {
    fontSize: 13,
    color: '#374151',
    fontWeight: '600',
  },
  categoryPillTextActive: {
    color: '#ffffff',
  },
  cropListScroll: {
    marginBottom: 20,
  },
  cropCard: {
    backgroundColor: '#ffffff',
    borderRadius: 14,
    width: 120,
    marginRight: 12,
    overflow: 'hidden',
    borderWidth: 2,
    borderColor: '#e5e7eb',
    elevation: 2,
    position: 'relative',
  },
  cropCardSelected: {
    borderColor: '#10b981',
    backgroundColor: '#ecfdf5',
  },
  cropThumbnail: {
    width: '100%',
    height: 75,
  },
  cropCardInfo: {
    padding: 8,
    alignItems: 'center',
  },
  cropEmoji: {
    fontSize: 18,
    marginBottom: 2,
  },
  cropName: {
    fontSize: 13,
    fontWeight: 'bold',
    color: '#1f2937',
    textAlign: 'center',
  },
  cropNameSelected: {
    color: '#059669',
  },
  cropSubName: {
    fontSize: 11,
    color: '#6b7280',
    textAlign: 'center',
  },
  checkmarkBadge: {
    position: 'absolute',
    top: 6,
    right: 6,
    backgroundColor: '#10b981',
    width: 22,
    height: 22,
    borderRadius: 11,
    justifyContent: 'center',
    alignItems: 'center',
  },
  checkText: {
    color: '#ffffff',
    fontWeight: 'bold',
    fontSize: 12,
  },
  uploadCard: {
    backgroundColor: '#ffffff',
    borderRadius: 16,
    padding: 16,
    marginBottom: 20,
    borderWidth: 1,
    borderColor: '#e5e7eb',
    elevation: 2,
  },
  uploadCardTitle: {
    fontSize: 14,
    fontWeight: '600',
    color: '#374151',
    marginBottom: 12,
  },
  previewContainer: {
    position: 'relative',
    borderRadius: 12,
    overflow: 'hidden',
    marginBottom: 14,
  },
  previewImage: {
    width: '100%',
    height: 200,
    borderRadius: 12,
  },
  removeImageBtn: {
    position: 'absolute',
    top: 10,
    right: 10,
    backgroundColor: 'rgba(0, 0, 0, 0.7)',
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 16,
  },
  removeImageText: {
    color: '#ffffff',
    fontSize: 12,
    fontWeight: 'bold',
  },
  emptyPreviewBox: {
    height: 140,
    backgroundColor: '#f9fafb',
    borderWidth: 2,
    borderColor: '#d1d5db',
    borderStyle: 'dashed',
    borderRadius: 12,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 14,
  },
  emptyPreviewEmoji: {
    fontSize: 34,
    marginBottom: 6,
  },
  emptyPreviewText: {
    fontSize: 14,
    fontWeight: '600',
    color: '#4b5563',
  },
  selectedCropNotice: {
    fontSize: 12,
    color: '#059669',
    marginTop: 4,
    fontWeight: '500',
  },
  photoActionsRow: {
    flexDirection: 'row',
    gap: 12,
  },
  actionButton: {
    flex: 1,
    minHeight: 50,
    borderRadius: 12,
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: 12,
  },
  cameraButton: {
    backgroundColor: '#10b981',
  },
  galleryButton: {
    backgroundColor: '#3b82f6',
  },
  actionBtnIcon: {
    fontSize: 18,
    marginRight: 8,
  },
  actionBtnText: {
    color: '#ffffff',
    fontSize: 14,
    fontWeight: 'bold',
  },
  diagnoseBtn: {
    backgroundColor: '#059669',
    minHeight: 54,
    borderRadius: 14,
    justifyContent: 'center',
    alignItems: 'center',
    elevation: 4,
    shadowColor: '#059669',
    shadowOpacity: 0.3,
    shadowRadius: 8,
  },
  diagnoseBtnDisabled: {
    backgroundColor: '#9ca3af',
  },
  diagnoseBtnText: {
    color: '#ffffff',
    fontSize: 17,
    fontWeight: 'bold',
  },
  loadingRow: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.6)',
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  modalContent: {
    backgroundColor: '#ffffff',
    width: '100%',
    borderRadius: 16,
    padding: 20,
  },
  modalHeaderTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#111827',
    marginBottom: 16,
    textAlign: 'center',
  },
  langModalItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: 12,
    paddingHorizontal: 16,
    borderRadius: 10,
    marginBottom: 8,
    backgroundColor: '#f9fafb',
  },
  langModalItemActive: {
    backgroundColor: '#d1fae5',
    borderColor: '#10b981',
    borderWidth: 1,
  },
  langItemNative: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#1f2937',
  },
  langItemEnglish: {
    fontSize: 12,
    color: '#6b7280',
  },
  langItemTextActive: {
    color: '#059669',
  },
  langSelectedCheck: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#059669',
  },
  modalCloseBtn: {
    marginTop: 10,
    paddingVertical: 12,
    alignItems: 'center',
  },
  modalCloseBtnText: {
    fontSize: 15,
    fontWeight: 'bold',
    color: '#6b7280',
  },
});
