import AsyncStorage from '@react-native-async-storage/async-storage';
import { LanguageCode } from './translations';

export interface DetectionRecord {
  id: string;
  crop_type: string;
  disease_name: string;
  confidence_score: number;
  treatment_steps: string[];
  fertilizer_suggestions: string[];
  prevention_tips: string[];
  image_uri?: string;
  language: string;
  created_at: string;
}

const STORAGE_KEYS = {
  HISTORY: '@crop_doctor_history',
  LANGUAGE: '@crop_doctor_language',
  OFFLINE_WEATHER: '@crop_doctor_weather',
};

// Language persistence
export async function saveSelectedLanguage(lang: LanguageCode): Promise<void> {
  try {
    await AsyncStorage.setItem(STORAGE_KEYS.LANGUAGE, lang);
  } catch (e) {
    console.error('Error saving language preference', e);
  }
}

export async function getSelectedLanguage(): Promise<LanguageCode> {
  try {
    const lang = await AsyncStorage.getItem(STORAGE_KEYS.LANGUAGE);
    if (lang && ['en', 'kn', 'ta', 'te', 'ml'].includes(lang)) {
      return lang as LanguageCode;
    }
  } catch (e) {
    console.error('Error reading language preference', e);
  }
  return 'en';
}

// History persistence
export async function saveDiagnosisToHistory(record: DetectionRecord): Promise<void> {
  try {
    const existing = await getLocalHistory();
    // Prepend to top
    const updated = [record, ...existing.filter((item) => item.id !== record.id)].slice(0, 50);
    await AsyncStorage.setItem(STORAGE_KEYS.HISTORY, JSON.stringify(updated));
  } catch (e) {
    console.error('Error saving diagnosis history', e);
  }
}

export async function getLocalHistory(): Promise<DetectionRecord[]> {
  try {
    const raw = await AsyncStorage.getItem(STORAGE_KEYS.HISTORY);
    if (raw) {
      return JSON.parse(raw);
    }
  } catch (e) {
    console.error('Error reading history', e);
  }
  return [];
}

export async function clearLocalHistory(): Promise<void> {
  try {
    await AsyncStorage.removeItem(STORAGE_KEYS.HISTORY);
  } catch (e) {
    console.error('Error clearing history', e);
  }
}

// Offline fallback diagnosis when completely offline
export function getOfflineDiagnosis(cropName: string, lang: LanguageCode): DetectionRecord {
  const titles: Record<string, Record<string, string>> = {
    Tomato: {
      en: "Early/Late Blight (Fungal Infection)",
      kn: "ಮುಂಚಿನ / ತಡವಾದ ಎಲೆ ಕರಕಲು ರೋಗ",
      ta: "இலை கருகல் நோய்",
      te: "ఆకు మాడు తెగులు",
      ml: "ഇല കരിച്ചിൽ രോഗം",
    },
    Rice: {
      en: "Rice Blast & Brown Leaf Spot",
      kn: "ಬೆಂಕಿ ರೋಗ ಮತ್ತು ಕಂದು ಚುಕ್ಕೆ ರೋಗ",
      ta: "குலை நோய் மற்றும் இலைப்புள்ளி",
      te: "అగ్గి తెగులు మరియు ఆకు మచ్చ",
      ml: "കുലരോഗവും ഇലപ്പുള്ളിയും",
    },
  };

  const diseaseName =
    titles[cropName]?.[lang] ||
    titles[cropName]?.['en'] ||
    `${cropName} Foliar Leaf Spot (Offline Analysis)`;

  return {
    id: `offline-${Date.now()}`,
    crop_type: cropName,
    disease_name: diseaseName,
    confidence_score: 0.85,
    treatment_steps: [
      lang === 'kn'
        ? "ಸೋಂಕಿತ ಎಲೆಗಳನ್ನು ತಕ್ಷಣ ಕಿತ್ತು ನಾಶಪಡಿಸಿ."
        : lang === 'ta'
        ? "பாதிக்கப்பட்ட இலைகளை உடனே அகற்றவும்."
        : lang === 'te'
        ? "వ్యాధి సోకిన ఆకులను తీసివేయండి."
        : lang === 'ml'
        ? "രോഗബാധയേറ്റ ഇലകൾ നീക്കം ചെയ്യുക."
        : "Prune and destroy infected leaves immediately.",
      lang === 'kn'
        ? "ಮ್ಯಾಂಕೋಜೆಬ್ ಅಥವಾ ತಾಮ್ರದ ಆಕ್ಸಿಕ್ಲೋರೈಡ್ ಸಿಂಪಡಿಸಿ."
        : lang === 'ta'
        ? "மேன்கோசெப் பூஞ்சைக்கொல்லி தெளிக்கவும்."
        : lang === 'te'
        ? "మాంకోజెబ్ లేదా కాపర్ ఆక్సిక్లోరైడ్ పిచಿಕారీ చేయండి."
        : lang === 'ml'
        ? "മാങ്കോസെബ് തളിക്കുക."
        : "Spray Mancozeb (2g/L) or Copper Oxychloride to prevent spore spread.",
    ],
    fertilizer_suggestions: [
      lang === 'kn'
        ? "ಕಳಿತ ಕೊಟ್ಟಿಗೆ ಗೊಬ್ಬರ ಮತ್ತು ಪೊಟ್ಯಾಶ್ ಒದಗಿಸಿ."
        : lang === 'ta'
        ? "தொழுவுரம் மற்றும் பொட்டாஷ் இடவும்."
        : lang === 'te'
        ? "పశువుల ఎరువు మరియు పొటాష్ వేయండి."
        : lang === 'ml'
        ? "ചാണകപ്പൊടിയും പൊട്ടാഷും നൽകുക."
        : "Apply organic Farm Yard Manure (FYM) and Potassium to improve plant vigor.",
    ],
    prevention_tips: [
      lang === 'kn'
        ? "ಗಿಡದ ಬುಡದಲ್ಲಿ ನೀರು ನಿಲ್ಲದಂತೆ ತಡೆಯಿರಿ."
        : lang === 'ta'
        ? "தண்ணீர் தேங்காமல் பார்த்துக் கொள்ளவும்."
        : lang === 'te'
        ? "నీరు నిల్వ ఉండకుండా చూడండి."
        : lang === 'ml'
        ? "വെള്ളക്കെട്ട് ഒഴിവാക്കുക."
        : "Avoid water stagnation and overhead sprinkler splashing.",
    ],
    language: lang,
    created_at: new Date().toISOString(),
  };
}
