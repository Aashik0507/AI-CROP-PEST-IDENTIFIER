# 🖼️ Crop Images & Asset Setup Guide

AI Crop Doctor displays high-resolution visual cards for all 20 supported crops. The app comes pre-configured with curated cloud CDN images and fallback agricultural icons, and optionally supports live dynamic imagery through the Pexels API.

---

## 🚀 Quick Setup (Pexels API)

1. **Get Free Pexels API Key**:
   - Visit [Pexels API Portal](https://www.pexels.com/api/)
   - Sign up for a free developer account (20,000 free requests/month).
   - Generate your API key.

2. **Configure the Key**:
   - In `frontend/.env`:
     ```env
     PEXELS_API_KEY=your_actual_pexels_api_key_here
     ```
   - Alternatively, add it to `frontend/utils/cropImages.ts`.

3. **Automatic 7-Day Caching**:
   - The app uses `@react-native-async-storage/async-storage` to cache fetched images for 7 days (`CACHE_EXPIRY_MS = 7 * 24 * 60 * 60 * 1000`).
   - Minimizes network bandwidth in rural farming areas.

---

## 🌾 Supported Crops Catalog (20 Types)

| Crop | Category | Default CDN Image | Offline Emoji |
| :--- | :--- | :--- | :--- |
| **Rice** | Cereals | Unsplash Rice Paddy | 🌾 |
| **Maize** | Cereals | Unsplash Corn Field | 🌽 |
| **Wheat** | Cereals | Unsplash Golden Wheat | 🌾 |
| **Cotton** | Cash Crops | Unsplash Cotton Boll | 🪴 |
| **Sugarcane** | Cash Crops | Unsplash Cane Field | 🎋 |
| **Turmeric** | Spices | Unsplash Turmeric Root | 🟡 |
| **Pepper** | Spices | Unsplash Black/Green Pepper | 🫑 |
| **Coconut** | Plantation | Unsplash Coconut Palms | 🥥 |
| **Arecanut** | Plantation | Unsplash Areca Plantation | 🌴 |
| **Tomato** | Vegetables | Unsplash Ripe Tomatoes | 🍅 |
| **Potato** | Vegetables | Unsplash Potato Plants | 🥔 |
| **Banana** | Fruits | Unsplash Banana Grove | 🍌 |
| **Mango** | Fruits | Unsplash Mango Tree | 🥭 |
| **Apple** | Fruits | Unsplash Apple Orchard | 🍎 |
| **Orange** | Fruits | Unsplash Citrus Trees | 🍊 |
| **Grapes** | Fruits | Unsplash Vineyard | 🍇 |
| **Strawberry**| Fruits | Unsplash Strawberry Field | 🍓 |
| **Papaya** | Fruits | Unsplash Papaya Tree | 🍈 |
| **Guava** | Fruits | Unsplash Guava Orchard | 🍏 |
| **Pomegranate**| Fruits | Unsplash Pomegranate Orchard | 🫐 |

---

## 📡 Offline Resilience

If the device is completely disconnected from the internet:
1. The app gracefully falls back to bundled high-contrast agricultural icons and emojis.
2. The UI remains 100% functional with zero broken image placeholders.
