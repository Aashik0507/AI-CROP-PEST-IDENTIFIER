import React from 'react';
import { Stack } from 'expo-router';
import { StatusBar } from 'expo-status-bar';

export default function RootLayout() {
  return (
    <>
      <StatusBar style="light" backgroundColor="#059669" />
      <Stack
        screenOptions={{
          headerStyle: {
            backgroundColor: '#10b981',
          },
          headerTintColor: '#ffffff',
          headerTitleStyle: {
            fontWeight: 'bold',
            fontSize: 20,
          },
          contentStyle: {
            backgroundColor: '#f0fdf4',
          },
        }}
      >
        <Stack.Screen
          name="index"
          options={{
            title: '🌾 AI Crop Doctor',
            headerShown: false,
          }}
        />
        <Stack.Screen
          name="analysis"
          options={{
            title: '🔍 Disease Diagnosis',
            headerBackTitle: 'Back',
          }}
        />
        <Stack.Screen
          name="history"
          options={{
            title: '📋 Detection History',
            headerBackTitle: 'Home',
          }}
        />
        <Stack.Screen
          name="weather"
          options={{
            title: '🌤️ Weather Advisory',
            headerBackTitle: 'Home',
          }}
        />
      </Stack>
    </>
  );
}
