import React, { useState, useEffect } from 'react';
import {
  StyleSheet,
  Text,
  View,
  FlatList,
  TouchableOpacity,
  Image,
  Alert,
  SafeAreaView,
} from 'react-native';
import { useRouter } from 'expo-router';
import {
  TRANSLATIONS,
  LanguageCode,
} from '../utils/translations';
import {
  DetectionRecord,
  getLocalHistory,
  clearLocalHistory,
  getSelectedLanguage,
} from '../utils/offlineStorage';
import { getCropEmoji, getCropImageSync } from '../utils/cropImages';

export default function HistoryScreen() {
  const router = useRouter();
  const [historyList, setHistoryList] = useState<DetectionRecord[]>([]);
  const [lang, setLang] = useState<LanguageCode>('en');
  const [loading, setLoading] = useState<boolean>(true);

  useEffect(() => {
    (async () => {
      const savedLang = await getSelectedLanguage();
      setLang(savedLang);
      await loadHistory();
    })();
  }, []);

  const loadHistory = async () => {
    setLoading(true);
    try {
      const records = await getLocalHistory();
      setHistoryList(records);
    } catch (e) {
      console.error('Error loading history:', e);
    } finally {
      setLoading(false);
    }
  };

  const handleClear = () => {
    Alert.alert(
      t.clearHistory,
      'Are you sure you want to clear all detection records?',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Clear',
          style: 'destructive',
          onPress: async () => {
            await clearLocalHistory();
            setHistoryList([]);
          },
        },
      ]
    );
  };

  const openDetails = (record: DetectionRecord) => {
    router.push({
      pathname: '/analysis',
      params: {
        data: JSON.stringify(record),
      },
    });
  };

  const t = TRANSLATIONS[lang] || TRANSLATIONS['en'];

  const renderItem = ({ item }: { item: DetectionRecord }) => {
    const confidencePct = Math.round((item.confidence_score || 0.8) * 100);
    const dateFormatted = new Date(item.created_at).toLocaleDateString(undefined, {
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });

    return (
      <TouchableOpacity
        style={styles.card}
        onPress={() => openDetails(item)}
        activeOpacity={0.8}
      >
        <Image
          source={{ uri: item.image_uri || getCropImageSync(item.crop_type) }}
          style={styles.cardImage}
          resizeMode="cover"
        />

        <View style={styles.cardDetails}>
          <View style={styles.cardHeaderRow}>
            <Text style={styles.cropTitle}>
              {getCropEmoji(item.crop_type)} {t.cropNames[item.crop_type] || item.crop_type}
            </Text>
            <Text style={styles.dateText}>{dateFormatted}</Text>
          </View>

          <Text style={styles.diseaseText} numberOfLines={1}>
            {item.disease_name}
          </Text>

          <View style={styles.cardFooter}>
            <View style={styles.confidencePill}>
              <Text style={styles.confidenceText}>{confidencePct}% accuracy</Text>
            </View>
            <Text style={styles.viewDetailText}>View Advice →</Text>
          </View>
        </View>
      </TouchableOpacity>
    );
  };

  return (
    <SafeAreaView style={styles.safeArea}>
      <View style={styles.container}>
        {/* Header Action Bar */}
        <View style={styles.topBar}>
          <Text style={styles.countText}>
            {historyList.length} {historyList.length === 1 ? 'scan' : 'scans'} saved
          </Text>
          {historyList.length > 0 && (
            <TouchableOpacity onPress={handleClear} style={styles.clearBtn}>
              <Text style={styles.clearBtnText}>🗑️ {t.clearHistory}</Text>
            </TouchableOpacity>
          )}
        </View>

        {historyList.length === 0 && !loading ? (
          <View style={styles.emptyContainer}>
            <Text style={styles.emptyEmoji}>📋</Text>
            <Text style={styles.emptyTitle}>{t.noHistory}</Text>
            <Text style={styles.emptyDesc}>{t.noHistoryDesc}</Text>
            <TouchableOpacity
              style={styles.startScanBtn}
              onPress={() => router.replace('/')}
            >
              <Text style={styles.startScanBtnText}>🌾 Scan Your First Crop</Text>
            </TouchableOpacity>
          </View>
        ) : (
          <FlatList
            data={historyList}
            keyExtractor={(item) => item.id}
            renderItem={renderItem}
            contentContainerStyle={styles.listContent}
            showsVerticalScrollIndicator={false}
          />
        )}
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
    backgroundColor: '#f0fdf4',
  },
  container: {
    flex: 1,
    padding: 16,
  },
  topBar: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 12,
  },
  countText: {
    fontSize: 14,
    color: '#4b5563',
    fontWeight: '600',
  },
  clearBtn: {
    backgroundColor: '#fee2e2',
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 8,
  },
  clearBtnText: {
    color: '#ef4444',
    fontSize: 13,
    fontWeight: '600',
  },
  listContent: {
    paddingBottom: 20,
  },
  card: {
    backgroundColor: '#ffffff',
    borderRadius: 14,
    marginBottom: 12,
    flexDirection: 'row',
    overflow: 'hidden',
    elevation: 2,
    borderWidth: 1,
    borderColor: '#e5e7eb',
  },
  cardImage: {
    width: 90,
    height: 90,
  },
  cardDetails: {
    flex: 1,
    padding: 10,
    justifyContent: 'space-between',
  },
  cardHeaderRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  cropTitle: {
    fontSize: 14,
    fontWeight: 'bold',
    color: '#111827',
  },
  dateText: {
    fontSize: 11,
    color: '#6b7280',
  },
  diseaseText: {
    fontSize: 14,
    fontWeight: '600',
    color: '#dc2626',
    marginTop: 2,
  },
  cardFooter: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginTop: 6,
  },
  confidencePill: {
    backgroundColor: '#d1fae5',
    paddingHorizontal: 8,
    paddingVertical: 3,
    borderRadius: 6,
  },
  confidenceText: {
    fontSize: 11,
    fontWeight: 'bold',
    color: '#059669',
  },
  viewDetailText: {
    fontSize: 12,
    fontWeight: '600',
    color: '#3b82f6',
  },
  emptyContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: 30,
  },
  emptyEmoji: {
    fontSize: 50,
    marginBottom: 12,
  },
  emptyTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#1f2937',
    marginBottom: 6,
    textAlign: 'center',
  },
  emptyDesc: {
    fontSize: 14,
    color: '#6b7280',
    textAlign: 'center',
    marginBottom: 20,
    lineHeight: 20,
  },
  startScanBtn: {
    backgroundColor: '#10b981',
    paddingHorizontal: 20,
    paddingVertical: 14,
    borderRadius: 12,
  },
  startScanBtnText: {
    color: '#ffffff',
    fontSize: 15,
    fontWeight: 'bold',
  },
});
