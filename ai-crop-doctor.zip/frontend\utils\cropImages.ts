import AsyncStorage from '@react-native-async-storage/async-storage';

// Optional Pexels API Key can be entered here or in .env
export const PEXELS_API_KEY = process.env.PEXELS_API_KEY || '';

const CACHE_KEY_PREFIX = '@crop_image_cache_';
const CACHE_EXPIRY_MS = 7 * 24 * 60 * 60 * 1000; // 7 days

// Pre-curated high-resolution agricultural CDN images for each of the 20 crops
export const CROP_DEFAULT_IMAGES: Record<string, string> = {
  Rice: "https://images.unsplash.com/photo-1536304993881-ff6e9eefa2a6?auto=format&fit=crop&w=600&q=80",
  Maize: "https://images.unsplash.com/photo-1551754655-cd27e38d2076?auto=format&fit=crop&w=600&q=80",
  Wheat: "https://images.unsplash.com/photo-1574323347407-f5e1ad6d020b?auto=format&fit=crop&w=600&q=80",
  Cotton: "https://images.unsplash.com/photo-1606041008023-472dfb5e530f?auto=format&fit=crop&w=600&q=80",
  Sugarcane: "https://images.unsplash.com/photo-1596783074918-c84cb06531ca?auto=format&fit=crop&w=600&q=80",
  Turmeric: "https://images.unsplash.com/photo-1615485290382-441e4d049cb5?auto=format&fit=crop&w=600&q=80",
  Pepper: "https://images.unsplash.com/photo-1588615419957-c6b7537b8d66?auto=format&fit=crop&w=600&q=80",
  Coconut: "https://images.unsplash.com/photo-1544476915-ed1370594142?auto=format&fit=crop&w=600&q=80",
  Arecanut: "https://images.unsplash.com/photo-1509358271058-acd22cc93898?auto=format&fit=crop&w=600&q=80",
  Tomato: "https://images.unsplash.com/photo-1592924357228-91a4daadcfea?auto=format&fit=crop&w=600&q=80",
  Potato: "https://images.unsplash.com/photo-1518977676601-b53f82aba655?auto=format&fit=crop&w=600&q=80",
  Banana: "https://images.unsplash.com/photo-1571771894821-ce9b6c11b08e?auto=format&fit=crop&w=600&q=80",
  Mango: "https://images.unsplash.com/photo-1553279768-865429fa0078?auto=format&fit=crop&w=600&q=80",
  Apple: "https://images.unsplash.com/photo-1560806887-1e4cd0b6cbd6?auto=format&fit=crop&w=600&q=80",
  Orange: "https://images.unsplash.com/photo-1547514701-42782101795e?auto=format&fit=crop&w=600&q=80",
  Grapes: "https://images.unsplash.com/photo-1537640538966-79f369143f8f?auto=format&fit=crop&w=600&q=80",
  Strawberry: "https://images.unsplash.com/photo-1464965911861-746a04b4bca6?auto=format&fit=crop&w=600&q=80",
  Papaya: "https://images.unsplash.com/photo-1517282009859-f000ec3b26fe?auto=format&fit=crop&w=600&q=80",
  Guava: "https://images.unsplash.com/photo-1536511135899-73f1d248b64e?auto=format&fit=crop&w=600&q=80",
  Pomegranate: "https://images.unsplash.com/photo-1615485290176-79659728b93d?auto=format&fit=crop&w=600&q=80",
};

export const CROP_EMOJIS: Record<string, string> = {
  Rice: "🌾",
  Maize: "🌽",
  Wheat: "🌾",
  Cotton: "🪴",
  Sugarcane: "🎋",
  Turmeric: "🟡",
  Pepper: "🫑",
  Coconut: "🥥",
  Arecanut: "🌴",
  Tomato: "🍅",
  Potato: "🥔",
  Banana: "🍌",
  Mango: "🥭",
  Apple: "🍎",
  Orange: "🍊",
  Grapes: "🍇",
  Strawberry: "🍓",
  Papaya: "🍈",
  Guava: "🍏",
  Pomegranate: "🫐",
};

export const CROP_CATEGORIES: Record<string, string[]> = {
  Cereals: ["Rice", "Maize", "Wheat"],
  "Cash Crops": ["Cotton", "Sugarcane"],
  Spices: ["Turmeric", "Pepper"],
  Plantation: ["Coconut", "Arecanut"],
  Vegetables: ["Tomato", "Potato"],
  Fruits: [
    "Banana",
    "Mango",
    "Apple",
    "Orange",
    "Grapes",
    "Strawberry",
    "Papaya",
    "Guava",
    "Pomegranate",
  ],
};

export async function fetchPexelsCropImage(cropName: string): Promise<string> {
  const cacheKey = `${CACHE_KEY_PREFIX}${cropName}`;
  try {
    const cached = await AsyncStorage.getItem(cacheKey);
    if (cached) {
      const parsed = JSON.parse(cached);
      if (Date.now() - parsed.timestamp < CACHE_EXPIRY_MS) {
        return parsed.url;
      }
    }
  } catch (e) {
    // fallback
  }

  if (PEXELS_API_KEY) {
    try {
      const res = await fetch(`https://api.pexels.com/v1/search?query=${encodeURIComponent(cropName + ' plant leaf')}&per_page=1`, {
        headers: { Authorization: PEXELS_API_KEY },
      });
      if (res.ok) {
        const json = await res.json();
        if (json.photos && json.photos.length > 0) {
          const photoUrl = json.photos[0].src.medium;
          await AsyncStorage.setItem(cacheKey, JSON.stringify({ url: photoUrl, timestamp: Date.now() }));
          return photoUrl;
        }
      }
    } catch (e) {
      console.warn('Pexels API fetch failed:', e);
    }
  }

  return CROP_DEFAULT_IMAGES[cropName] || "https://images.unsplash.com/photo-1530836369250-ef72a3f5cda8?auto=format&fit=crop&w=600&q=80";
}

export function getCropImageSync(cropName: string): string {
  return CROP_DEFAULT_IMAGES[cropName] || "https://images.unsplash.com/photo-1530836369250-ef72a3f5cda8?auto=format&fit=crop&w=600&q=80";
}

export function getCropEmoji(cropName: string): string {
  return CROP_EMOJIS[cropName] || "🌱";
}
